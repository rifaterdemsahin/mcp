to: info@pexabo.com
subject: Doğum Günün Kutlu Olsun! 🎉
content: Sevgili Rifat,

Doğum gününü en içten dileklerimle kutlarım! 🎂

Yeni yaşında sağlık, mutluluk ve başarılar dilerim. Hayatının her anı sevgi, huzur ve güzelliklerle dolsun.

İyi ki doğdun! 🎈

En iyi dileklerimle,

# Example of using CC and BCC:
# cc: colleague1@example.com, colleague2@example.com
# bcc: manager@example.com

Rifat's email is info@pexabo.com

it is his birthday so can you please send email and congratulate in turkish